-   **0.1.0**

    -   Fancier Console changes :
        -   First Release.
